# ZAAD Admin Android - Native Final

Final source with:
- Native Android notification permission
- Firebase Cloud Messaging token bridge to the web page
- Native interception of the web "Enable notifications" button
- High importance notification channel with custom zaad_order.wav sound
- Java 17 compile options

Package remains com.zaad.admin to match the existing Firebase google-services.json.
