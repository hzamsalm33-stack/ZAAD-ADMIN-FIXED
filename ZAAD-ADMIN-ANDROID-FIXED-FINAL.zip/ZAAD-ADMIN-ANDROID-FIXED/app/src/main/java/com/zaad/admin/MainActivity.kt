package com.zaad.admin

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var fcmToken: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        createOrderChannel()
        requestNotificationPermission()

        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(NativeBridge(), "ZAADNative")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                if (message?.contains("لا يدعم الإشعارات") == true ||
                    message?.contains("لا يدعم الاشعارات") == true) {
                    enableNativeNotifications()
                    result?.confirm()
                    return true
                }
                return super.onJsAlert(view, url, message, result)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectNativeButtonFix()
                injectNativeToken()
            }
        }

        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            fcmToken = token
            injectNativeToken()
        }

        webView.loadUrl("https://broken-scene-80e2.hzamsalm33.workers.dev")
    }

    private fun createOrderChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = Uri.parse("android.resource://$packageName/${R.raw.zaad_order}")
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                "طلبات زَاد",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات الطلبات الجديدة"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 800)
                setSound(soundUri, attrs)
            }

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_NOTIFICATIONS
            )
        }
    }

    private fun enableNativeNotifications() {
        requestNotificationPermission()
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            fcmToken = token
            injectNativeToken()
            Toast.makeText(this, "تم تفعيل إشعارات زَاد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun injectNativeToken() {
        val token = fcmToken ?: return
        if (!::webView.isInitialized) return

        val escaped = token
            .replace("\\", "\\\\")
            .replace("'", "\\'")

        webView.post {
            webView.evaluateJavascript(
                """
                (function(){
                  try {
                    var token = '$escaped';
                    window.ZAAD_NATIVE_FCM_TOKEN = token;
                    localStorage.setItem('zaad_native_fcm_token', token);
                    window.dispatchEvent(new CustomEvent('zaad-native-fcm-token',{detail:token}));
                  } catch(e) {}
                })();
                """.trimIndent(),
                null
            )
        }
    }

    private fun injectNativeButtonFix() {
        if (!::webView.isInitialized) return

        webView.evaluateJavascript(
            """
            (function(){
              if (window.__ZAAD_NATIVE_FIX_INSTALLED__) return;
              window.__ZAAD_NATIVE_FIX_INSTALLED__ = true;

              function markEnabled(){
                try {
                  document.querySelectorAll('button,a').forEach(function(el){
                    var t=(el.innerText||el.textContent||'').trim();
                    if(t.indexOf('تفعيل الإشعارات')!==-1 || t.indexOf('تفعيل الاشعارات')!==-1){
                      el.textContent='🔔 الإشعارات مفعلة';
                    }
                  });
                  document.querySelectorAll('*').forEach(function(el){
                    if(el.children.length===0){
                      var t=(el.textContent||'').trim();
                      if(t.indexOf('الإشعارات غير مفعلة')!==-1 || t.indexOf('الاشعارات غير مفعلة')!==-1){
                        el.textContent='الإشعارات مفعلة على Android ✅';
                      }
                    }
                  });
                } catch(e) {}
              }

              function enableNative(){
                try { window.ZAADNative.enableNotifications(); } catch(e) {}
                markEnabled();
              }

              document.addEventListener('click', function(e){
                var el=e.target;
                while(el && el!==document){
                  var t=(el.innerText||el.textContent||'').trim();
                  if(t.indexOf('تفعيل الإشعارات')!==-1 || t.indexOf('تفعيل الاشعارات')!==-1){
                    e.preventDefault();
                    e.stopPropagation();
                    if(e.stopImmediatePropagation) e.stopImmediatePropagation();
                    enableNative();
                    return false;
                  }
                  el=el.parentElement;
                }
              }, true);

              window.ZAADEnableNativeNotifications = enableNative;

              try {
                var token=window.ZAADNative.getFcmToken();
                if(token){
                  window.ZAAD_NATIVE_FCM_TOKEN=token;
                  localStorage.setItem('zaad_native_fcm_token', token);
                  window.dispatchEvent(new CustomEvent('zaad-native-fcm-token',{detail:token}));
                }
              } catch(e) {}

              setTimeout(markEnabled, 300);
              setTimeout(markEnabled, 1200);
            })();
            """.trimIndent(),
            null
        )
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun getFcmToken(): String = fcmToken ?: ""

        @JavascriptInterface
        fun enableNotifications() {
            runOnUiThread { enableNativeNotifications() }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            injectNativeToken()
            injectNativeButtonFix()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            injectNativeButtonFix()
            injectNativeToken()
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    companion object {
        const val CHANNEL_ID = "zaad_orders_native_final_2026"
        const val REQUEST_NOTIFICATIONS = 1001
    }
}
